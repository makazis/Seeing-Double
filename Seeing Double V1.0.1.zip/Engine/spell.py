import os
import json
import pygame
import Engine.card_manager as cardman
from useful_stuff import *
spell_data={}
for root, dirs, files in os.walk(r"Resources/spells/"):
    for file in files:
        if file.endswith(".json"):
            with open(os.path.join(root,file),"r") as f:
                spell_data[file[:-5]]=json.loads(f.read())
card_overlay=pygame.image.load("Resources/images/cards/p.png")
card_overlay.set_colorkey(cardman.card_transparency_color)
inv_card_overlay=pygame.image.load("Resources/images/cards/inv_p.png")
inv_card_overlay.set_colorkey(cardman.card_transparency_color)

class Spell:
    def __init__(self,id):
        self.id=id #Will use this later, just needed for board things rn
        self.data=spell_data[self.id].copy()
        self.type="Spell"
        self.inv=False
        self.exhausted=False
    def draw(self,side_on,inv=False):
        if inv or self.inv:
            self.inv=True
            self.card.side_from_surface(cardman.cardSideImages["inv"], "Back")
            self.card.side_from_surface(pygame.Surface((210,320)),side_on)
            self.card.sides[side_on].fill((1,0,0)) #Replace this with image handling when the time comes
            self.card.sides[side_on].blit(inv_card_overlay,(0,0))
            center(render_text(self.data["Card Data"]["Name"],14,(0,0,1),"Consolas"),self.card.sides[side_on],105,135)
            card_desc=self.data["Card Data"]["Description"]
            for I,i in enumerate(card_desc):
                y_pos=I-(len(card_desc)-1)/2
                center(render_text(i,14,(0,1,0),"Consolas"),self.card.sides[side_on],105,226+y_pos*20)
            if "Rarity" in self.data:
                if self.data["Rarity"]=="Uncommon":
                    pygame.draw.rect(self.card.sides[side_on],(0,255,255),(0,0,210,320),2,15)
                if self.data["Rarity"]=="Rare":
                    pygame.draw.rect(self.card.sides[side_on],(255,255,0),(0,0,210,320),2,15)
                if self.data["Rarity"]=="Cursed":
                    pygame.draw.rect(self.card.sides[side_on],(125,0,195),(0,0,210,320),2,15)
                
            self.card.sides[side_on].blit(card_transparency_overlay,(0,0))
            
        else:
            self.card.side_from_surface(cardman.cardSideImages["default-back"], "Back")
            self.card.side_from_surface(pygame.Surface((210,320)),side_on)
            self.card.sides[side_on].fill((255,255,254)) #Replace this with image handling when the time comes
            self.card.sides[side_on].blit(card_overlay,(0,0))
            center(render_text(self.data["Card Data"]["Name"],14,(255,254,255),"Consolas"),self.card.sides[side_on],105,135)
            card_desc=self.data["Card Data"]["Description"]
            for I,i in enumerate(card_desc):
                y_pos=I-(len(card_desc)-1)/2
                center(render_text(i,14,(253,255,255),"Consolas"),self.card.sides[side_on],105,226+y_pos*20)
            if "Rarity" in self.data:
                if self.data["Rarity"]=="Uncommon":
                    pygame.draw.rect(self.card.sides[side_on],(0,255,255),(0,0,210,320),2,15)
                if self.data["Rarity"]=="Rare":
                    pygame.draw.rect(self.card.sides[side_on],(255,255,0),(0,0,210,320),2,15)
                if self.data["Rarity"]=="Cursed":
                    pygame.draw.rect(self.card.sides[side_on],(125,0,195),(0,0,210,320),2,15)
                
            self.card.sides[side_on].blit(card_transparency_overlay,(0,0))
            
            #pygame.image.save(self.card.sides[side_on],"t.png")
        for I in range(self.data["Energy Cost"]):
            center(mid_energy_icon,self.card.sides[side_on],15+I*40,15)
"""
    new_object_manager.
        new_object_manager.card.side_from_surface(pygame.Surface((210,320)),side_on)
            new_object_manager.card.sides[side_on].fill((0,0,0)) #Replace this with image handling when the time comes
    else:
            new_object_manager.card.side_from_surface(cardSideImages["default-back"], "Back")"""